from django.db import models

class MyModel(models.Model):
    entries = models.TextField()
    